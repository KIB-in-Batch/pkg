ECHO %*
