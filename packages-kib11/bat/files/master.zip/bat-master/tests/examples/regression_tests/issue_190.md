```javascript
var test = "boom";
```
