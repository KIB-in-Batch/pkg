The `test.wgsl` file has been added from https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API under the following license:

```
Any copyright is dedicated to the Public Domain: https://creativecommons.org/publicdomain/zero/1.0/
```
