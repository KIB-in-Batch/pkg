return Object(
  Object(
    // Not highlighted as a comment
  )
)
